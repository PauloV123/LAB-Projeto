
import java.util.Iterator;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.Random;

public class Jacare extends Player{
	public Jacare(int x, int y,int vel){
		super(x,y,1);
	}
	public void move(){
	  
	}
}