
import java.util.Iterator;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.Random;

public class Leao extends Player{
  public Leao(int x, int y,int vel){
		super(x,y,3);
	}
	public void move(){
	  
	}
}