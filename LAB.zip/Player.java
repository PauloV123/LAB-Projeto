
import java.util.Iterator;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.Random;

public class Player{
	protected int x; 
	protected int y; 
	protected int vel;
	
	public Player(int x,int y,int vel){
		this.x = x;
		this.y = y;
		this.vel=vel;

}
	
/*	public void move(){
	  while(true){
	  if(vel == 1){
	    Random random = new Random();
	    int movimento = random.nextInt(4);
	  }
  }
}*/
public void setVel(int vel){
		this.vel = vel;
}
	public int getVel(){
		return vel;
	}
	
	public void setX(int x){
		this.x = x;
	}
	public void setY(int y){
		this.y = y;
	}
	
	public int getX(){
		return x;
	}
	public int getY(){
		return y;
	}  
}