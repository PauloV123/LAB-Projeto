import java.util.Iterator;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.Random;

class Main {
  public static void main(String[] args) {
     	Mundo M = new Mundo();
     	M.criaMundo();
     	M.setPlayer();
     	M.imprimeMundo();
     	//M.setInimigos();
     	
     	ArrayList<Cobra> c = new ArrayList<>();
     	ArrayList<Leao> l = new ArrayList<>();
     	ArrayList<Jacare> j = new ArrayList<>();
    for(int i =0;i<3;i++){ 	
     	int xcobra = (int)(Math.random() * 68);
     	int ycobra = (int)(Math.random() * 28);
     	int xleao = (int)(Math.random() * 68);
     	int yleao = (int)(Math.random() * 28);
     	int xjacare = (int)(Math.random() * 68);
     	int yjacare = (int)(Math.random() * 28);
     	
     	c.add(new Cobra(xcobra,ycobra,2));
		  l.add(new Leao(xleao,yleao,3));
		  j.add(new Jacare(xjacare,yjacare,1));
    }
     	for(int i=0;i<3;i++){
     	M.setEnemies(c.get(i).getX(), c.get(i).getY(), 2);
     	M.setEnemies(l.get(i).getX(), l.get(i).getY(), 3);
     	M.setEnemies(j.get(i).getX(), j.get(i).getY(), 1);
     	
     	}
     	M.imprimeMundo();
  }
}