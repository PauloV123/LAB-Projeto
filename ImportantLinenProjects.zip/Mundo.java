import java.util.Iterator;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.Random;

public class Mundo{
	public void criaMundo(){
  	int i,j;
	  	for(i=0;i<30;i++){
	  		for(j=0;j<70;j++){
	  			mundo[i][j] = 0;
	  			mundo[i][0] = 1; 
	  			mundo[i][69] = 1; 
	  			mundo[0][j] = 1; 
	  			mundo[29][j] = 1; 
	  		}
	  	}
  	}
	  	
public void imprimeMundo(){
  for(int i=0;i<30;i++){
	  System.out.println("");
	  for(int j=0;j<70;j++){
		  System.out.printf("%d", mundo[i][j]);
		}
	}
}
public void setPlayer(){
			mundo[0][35] = 2;
}
public void setEnemies(int x,int y,int tipo){
		if(tipo == 2){
			mundo[x][y] = 8;
		}
		else if(tipo == 1){
			mundo[x][y] = 7;
		}
		else if(tipo == 3){
			mundo[x][y] = 9;
		}

	}
	
private int [][]mundo = new int [30][70];
}