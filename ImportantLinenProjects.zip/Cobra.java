
import java.util.Iterator;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.Random;

public class Cobra extends Player {
	public Cobra(int x, int y,int vel){
		super(x,y,2);
	}
	public void move(){
	  
	}
}